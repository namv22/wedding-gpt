export const wedding = {
  bride: 'Bích Thảo',
  groom: 'Hoàng Nam',
  eventTitle: 'Lễ Vu Quy',
  date: '2026-11-15',
  // Set this to the confirmed ceremony time (24-hour HH:mm). Leave empty until confirmed.
  time: '',
  timeZone: 'Asia/Ho_Chi_Minh',
  language: 'vi',
  welcomeMessage: 'Trân trọng kính mời bạn đến chung vui và chứng kiến khoảnh khắc đặc biệt của chúng mình.',
  closingMessage: 'Cảm ơn bạn đã dành tình cảm và thời gian chung vui cùng gia đình chúng mình. Sự hiện diện của bạn sẽ làm ngày trọng đại này thêm trọn vẹn.',
  story: {
    enabled: false,
    heading: 'Chuyện chúng mình',
    introduction: '',
    milestones: [] as { date: string; title: string; description: string }[],
  },
  family: {
    bride: { father: '', mother: '', address: '' },
    groom: { father: '', mother: '', address: '' },
  },
  venue: {
    name: 'Đang cập nhật địa điểm',
    address: '',
    mapUrl: '',
    note: '',
  },
  schedule: [
    { time: '', title: 'Đón khách', description: '', venue: '' },
    { time: '', title: 'Lễ Vu Quy', description: '', venue: '' },
    { time: '', title: 'Tiệc cưới', description: '', venue: '' },
  ],
  rsvp: {
    deadline: '2026-11-01',
    maxGuests: 5,
    heading: 'Xác nhận tham dự',
    description: 'Sự hiện diện của bạn là niềm vui của chúng mình. Vui lòng xác nhận để gia đình chuẩn bị chu đáo hơn nhé!',
  },
  contacts: [
    // Add real contact details here, e.g. { label: 'Cô dâu', phone: '09...' }
  ] as { label: string; phone?: string; email?: string; messageUrl?: string }[],
  social: {
    title: 'Lễ Vu Quy · Bích Thảo & Hoàng Nam',
    description: 'Trân trọng kính mời bạn đến chung vui ngày 15.11.2026.',
    image: '/social-preview.jpg',
  },
} as const
